self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0f9421b18ffdeb01b0060c2982eaa947",
    "url": "/index.html"
  },
  {
    "revision": "2abbe8a9cbb4cee7f458",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "c7f3f31a9906a709e62f",
    "url": "/static/css/main.0971e629.chunk.css"
  },
  {
    "revision": "2abbe8a9cbb4cee7f458",
    "url": "/static/js/2.ddb492a3.chunk.js"
  },
  {
    "revision": "87f1c48a6b299dccc37ab9301d949db7",
    "url": "/static/js/2.ddb492a3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c7f3f31a9906a709e62f",
    "url": "/static/js/main.3b7f6fcb.chunk.js"
  },
  {
    "revision": "05c1d87d7a249a2a66a5",
    "url": "/static/js/runtime-main.be5e22a7.js"
  },
  {
    "revision": "e8f451ed13e4e4c34521a5ac8e5f37b4",
    "url": "/static/media/earth.e8f451ed.png"
  },
  {
    "revision": "278922fb0b12ba8dd096f1a77d04d905",
    "url": "/static/media/monocle.278922fb.png"
  },
  {
    "revision": "732e4b67943c2c5be3ad4b21c7bc8943",
    "url": "/static/media/notebook.732e4b67.png"
  },
  {
    "revision": "cf0da2fbd6350a89deba0b431afe5328",
    "url": "/static/media/party.cf0da2fb.png"
  },
  {
    "revision": "c4d8d98fc7ba5277f11c423108569be9",
    "url": "/static/media/pensive.c4d8d98f.png"
  }
]);